HYUNDAI OS — PROYECTO ANDROID TV (base 1.0.0)

Este proyecto integra la interfaz web HYUNDAI OS 2.1 dentro de una aplicación Android con WebView y puente JavaScript nativo para abrir aplicaciones instaladas.

IMPORTANTE
- Este ZIP es el PROYECTO FUENTE, no es todavía un APK instalable.
- El APK debe compilarse mediante Gradle/Android SDK. Se incluye GitHub Actions para compilarlo en la nube desde una cuenta GitHub.
- El APK se declara como launcher HOME/LEANBACK. Android puede mostrar un selector para elegir pantalla de inicio; el fabricante puede restringir esta función.
- Los paquetes de aplicaciones son aproximados y deben coincidir con los instalados en el televisor. Si una aplicación no abre, hay que verificar su package ID.
- El clima requiere conexión a internet.
- No se solicita permiso de almacenamiento amplio; la biblioteca usa el selector de archivos Android.

COMPILACIÓN EN LA NUBE
1. Crear un repositorio privado en GitHub desde el navegador de la tablet.
2. Subir el contenido completo de este proyecto a la rama main, conservando la carpeta .github/workflows.
3. Abrir la pestaña Actions y ejecutar “Build HYUNDAI OS APK” (o esperar al build automático al subir a main).
4. Cuando termine, descargar el artifact “HYUNDAI-OS-debug-apk” y extraer app-debug.apk.
5. Transferir el APK al televisor e instalarlo. La instalación puede requerir habilitar temporalmente instalar aplicaciones desconocidas para la app que lo abre.

No seleccionar HYUNDAI OS como inicio predeterminado hasta comprobar que abre y que se puede volver a Google TV.
