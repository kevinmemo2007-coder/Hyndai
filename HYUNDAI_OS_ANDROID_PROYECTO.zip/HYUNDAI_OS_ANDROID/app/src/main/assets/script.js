/* HYUNDAI OS 2.1 — navegación TV reforzada */
(() => {
'use strict';
const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const appData = [
  {name:'Netflix', icon:'N', pkg:'com.netflix.ninja', key:'netflix'},
  {name:'YouTube', icon:'▶', pkg:'com.google.android.youtube.tv', key:'youtube'},
  {name:'Spotify', icon:'♫', pkg:'com.spotify.tv.android', key:'spotify'},
  {name:'Prime Video', icon:'▶', pkg:'com.amazon.amazonvideo.livingroom', key:'prime'},
  {name:'Disney+', icon:'✦', pkg:'com.disney.disneyplus', key:'disney'},
  {name:'Max', icon:'M', pkg:'com.wbd.stream', key:'max'},
  {name:'YouTube Music', icon:'♫', pkg:'com.google.android.youtube.tvmusic', key:'music'},
  {name:'SoundCloud', icon:'☁', pkg:'com.soundcloud.android', key:'soundcloud'},
  {name:'Zuper TV', icon:'Z', pkg:'com.zuper.fire', key:'zuper'},
  {name:'Google TV', icon:'G', pkg:'com.google.android.videos', key:'google'}
];
let currentView='home', toastTimer=null, activeUrl=null, mediaItems=[];
function toast(message){const el=$('#toast');if(!el)return;el.textContent=message;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),3200);}
function visible(el){return !!(el && el.getClientRects().length && getComputedStyle(el).visibility!=='hidden' && !el.closest('[hidden]'));}
function focusFirst(view){const panel=$('#view-'+view);if(!panel)return;const first=$$('.app-tile,button,.file-label',panel).find(visible);if(first){setTimeout(()=>first.focus(),80);}}
function setView(name){const panel=$('#view-'+name);if(!panel)return;currentView=name;$$('[data-view-panel]').forEach(p=>p.classList.toggle('active',p.dataset.viewPanel===name));$$('.nav-item').forEach(b=>{const active=b.dataset.view===name;b.classList.toggle('active',active);b.setAttribute('aria-current',active?'page':'false');});window.scrollTo(0,0);focusFirst(name);}
// Delegación de eventos: evita perder la acción al regenerar botones.
document.addEventListener('click', e=>{
  const nav=e.target.closest('.nav-item[data-view]');
  if(nav){e.preventDefault();setView(nav.dataset.view);return;}
  const go=e.target.closest('[data-go]');
  if(go){e.preventDefault();setView(go.dataset.go);return;}
  const tile=e.target.closest('.app-tile');
  if(tile){e.preventDefault();launchApp(tile.dataset.package||'',tile.dataset.appName||'Aplicación');return;}
  const spotify=e.target.closest('[data-app="spotify"]');
  if(spotify){e.preventDefault();launchApp('com.spotify.tv.android','Spotify');}
});
// Hora local de Colombia, actualizada aunque la página permanezca abierta.
function updateClock(){const now=new Date();const time=$('#time'),date=$('#date');if(time)time.textContent=new Intl.DateTimeFormat('es-CO',{hour:'2-digit',minute:'2-digit',hour12:true,timeZone:'America/Bogota'}).format(now);if(date)date.textContent=new Intl.DateTimeFormat('es-CO',{weekday:'long',day:'numeric',month:'long',timeZone:'America/Bogota'}).format(now);}
updateClock();setInterval(updateClock,1000);
function weatherCode(code){if(code===0)return ['☀','Despejado'];if([1,2].includes(code))return ['🌤','Parcialmente nublado'];if(code===3)return ['☁','Nublado'];if([45,48].includes(code))return ['🌫','Neblina'];if([51,53,55,56,57].includes(code))return ['🌦','Llovizna'];if([61,63,65,66,67,80,81,82].includes(code))return ['🌧','Lluvia'];if([71,73,75,77,85,86].includes(code))return ['🌨','Nieve'];if([95,96,99].includes(code))return ['⛈','Tormenta'];return ['🌡','Condiciones variables'];}
async function loadWeather(){const desc=$('#weatherText');if(!desc)return;desc.textContent='Consultando clima…';try{const endpoint='https://api.open-meteo.com/v1/forecast?latitude=7.1193&longitude=-73.1227&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m&timezone=America%2FBogota';const response=await fetch(endpoint,{method:'GET',cache:'no-store'});if(!response.ok)throw new Error('Servicio no disponible');const data=await response.json();if(!data.current)throw new Error('Sin datos actuales');const c=data.current,[icon,label]=weatherCode(c.weather_code);$('#weatherIcon').textContent=icon;$('#weatherTemp').textContent=Math.round(c.temperature_2m)+'°';desc.textContent=label;$('#weatherDetail').textContent='Sensación '+Math.round(c.apparent_temperature)+'° · Humedad '+c.relative_humidity_2m+'% · Viento '+Math.round(c.wind_speed_10m)+' km/h';}catch(err){$('#weatherIcon').textContent='☁';$('#weatherTemp').textContent='--°';desc.textContent='Clima temporalmente no disponible';$('#weatherDetail').textContent='El visor debe permitir conexión HTTPS. Pulsa Actualizar para reintentar.';}}
$('#refreshWeather')?.addEventListener('click',loadWeather);$('#settingsWeather')?.addEventListener('click',loadWeather);loadWeather();setInterval(loadWeather,30*60*1000);
function launchApp(pkg,name){if(!pkg){toast('No hay paquete de Android configurado para '+name+'.');return;}if(window.AndroidTV&&typeof window.AndroidTV.launchApp==='function'){window.AndroidTV.launchApp(pkg,name);return;}toast('Esta función requiere HYUNDAI OS instalada como APK.');}
function makeAppTile(app){const b=document.createElement('button');b.type='button';b.className='app-tile';b.dataset.package=app.pkg;b.dataset.appName=app.name;b.setAttribute('aria-label','Abrir '+app.name);const logo=document.createElement('span');logo.className='app-logo app-logo-'+app.key;logo.textContent=app.icon;const name=document.createElement('span');name.textContent=app.name;const note=document.createElement('small');note.textContent='Seleccionar para abrir';b.append(logo,name,note);return b;}
function renderApps(){const all=$('#allApps'),home=$('#homeApps');if(!all||!home)return;all.replaceChildren();home.replaceChildren();appData.forEach((app,index)=>{all.appendChild(makeAppTile(app));if(index<6)home.appendChild(makeAppTile(app));});}
renderApps();
const mediaPicker=$('#mediaPicker'),mediaGrid=$('#mediaGrid'),libraryCount=$('#libraryCount');
function renderMedia(){if(!mediaGrid)return;mediaGrid.replaceChildren();if(!mediaItems.length){mediaGrid.innerHTML='<div class="empty-state"><div>▣</div><h3>Tu biblioteca está vacía</h3><p>Selecciona “Añadir archivos” para elegir vídeos o música del televisor.</p></div>';if(libraryCount)libraryCount.textContent='Todavía no has añadido archivos';return;}if(libraryCount)libraryCount.textContent=mediaItems.length+' archivo(s) seleccionado(s)';mediaItems.forEach((file,index)=>{const b=document.createElement('button');b.type='button';b.className='media-item';const icon=document.createElement('span');icon.className='media-icon';icon.textContent=file.type.startsWith('video')?'🎬':'♫';const info=document.createElement('span');info.style.minWidth='0';const title=document.createElement('b');title.textContent=file.name;const detail=document.createElement('small');detail.textContent=Math.max(1,Math.round(file.size/104857.6)/10)+' MB · '+(file.type.startsWith('video')?'Vídeo':'Audio');info.append(title,detail);b.append(icon,info);b.addEventListener('click',()=>playMedia(index));mediaGrid.appendChild(b);});}
mediaPicker?.addEventListener('change',e=>{mediaItems=[...mediaItems,...Array.from(e.target.files||[])];renderMedia();if(mediaItems.length)toast('Archivos añadidos a la biblioteca.');});
function playMedia(index){const file=mediaItems[index];if(!file)return;if(activeUrl)URL.revokeObjectURL(activeUrl);activeUrl=URL.createObjectURL(file);$('#playerTitle').textContent=file.name;const video=$('#mediaPlayer'),audio=$('#audioPlayer');video.hidden=!file.type.startsWith('video');audio.hidden=file.type.startsWith('video');if(video.hidden){video.pause();audio.src=activeUrl;audio.play().catch(()=>toast('Pulsa reproducir en el reproductor de audio.'));}else{audio.pause();video.src=activeUrl;video.play().catch(()=>toast('Pulsa reproducir en el reproductor de vídeo.'));}$('#playerWrap').hidden=false;}
$('#closePlayer')?.addEventListener('click',()=>{const video=$('#mediaPlayer'),audio=$('#audioPlayer');video.pause();audio.pause();video.removeAttribute('src');audio.removeAttribute('src');$('#playerWrap').hidden=true;if(activeUrl){URL.revokeObjectURL(activeUrl);activeUrl=null;}});
$('#clearLibrary')?.addEventListener('click',()=>{mediaItems=[];if(mediaPicker)mediaPicker.value='';$('#closePlayer')?.click();renderMedia();});renderMedia();
// Navegación compatible con controles que envían Enter, DPAD_CENTER o keyCode Android.
function focusables(){return $$('button:not(:disabled),.file-label').filter(el=>visible(el)&&!el.closest('[hidden]'));}
function moveFocus(direction){const elements=focusables();if(!elements.length)return;const current=document.activeElement;if(!elements.includes(current)){const active=$('.nav-item.active');(active&&visible(active)?active:elements[0]).focus();return;}const a=current.getBoundingClientRect(),ax=a.left+a.width/2,ay=a.top+a.height/2;let best=null,bestScore=Infinity;for(const el of elements){if(el===current)continue;const r=el.getBoundingClientRect(),dx=r.left+r.width/2-ax,dy=r.top+r.height/2-ay;let primary,secondary,valid;if(direction==='right'||direction==='left'){valid=direction==='right'?dx>3:dx< -3;primary=Math.abs(dx);secondary=Math.abs(dy);}else{valid=direction==='down'?dy>3:dy< -3;primary=Math.abs(dy);secondary=Math.abs(dx);}if(!valid)continue;const score=primary+secondary*1.6;if(score<bestScore){best=el;bestScore=score;}}if(best){best.focus();best.scrollIntoView({block:'nearest',inline:'nearest'});}}
document.addEventListener('keydown',event=>{const key=event.key||'';const code=event.keyCode||event.which;const directions={ArrowRight:'right',ArrowLeft:'left',ArrowUp:'up',ArrowDown:'down'};if(directions[key]||[21,22,19,20].includes(code)){event.preventDefault();moveFocus(directions[key]||({21:'left',22:'right',19:'up',20:'down'})[code]);return;}if(['Enter',' ','Select','NumpadEnter'].includes(key)||[13,23,66].includes(code)){const target=document.activeElement;if(target&&target.matches('button,.file-label')){event.preventDefault();target.click();}return;}if(key==='Escape'||key==='Backspace'||code===4){if(!$('#playerWrap').hidden){$('#closePlayer')?.click();return;}if(currentView!=='home'){event.preventDefault();setView('home');}}});
window.addEventListener('load',()=>{const active=$('.nav-item.active');if(active)active.focus();});
})();
